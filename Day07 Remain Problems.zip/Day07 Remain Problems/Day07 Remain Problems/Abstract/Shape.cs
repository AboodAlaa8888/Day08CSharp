﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day07_Remain_Problems.Abstract
{
    public abstract class Shape
    {
        // Virtual method
        public virtual void Draw()
        {
            Console.WriteLine("Drawing Shape");
        }

        // Abstract method
        public abstract double CalculateArea();
    }

}
