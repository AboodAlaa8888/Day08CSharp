﻿using Day07_Remain_Problems.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day07_Remain_Problems
{
    public class Car : IMovable
    {
        public string Model { get; set; }

        public Car(string model)
        {
            Model = model;
        }

        // Implement the Move method
        public void Move()
        {
            Console.WriteLine($"{Model} is moving on the road...");
        }
    }
}
