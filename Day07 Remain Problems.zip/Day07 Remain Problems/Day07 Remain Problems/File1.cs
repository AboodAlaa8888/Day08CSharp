﻿using Day07_Remain_Problems.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day07_Remain_Problems
{
    public class File1 : IReadable, IWritable
    {
        public string FileName { get; set; }

        public File1(string fileName)
        {
            FileName = fileName;
        }

        // Implement Read
        public void Read()
        {
            Console.WriteLine($"Reading data from {FileName}...");
        }

        // Implement Write
        public void Write()
        {
            Console.WriteLine($"Writing data to {FileName}...");
        }
    }
}
