﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day07_Remain_Problems.Interface
{
    public interface IMovable
    {
        void Move();   // Method signature
    }
}
