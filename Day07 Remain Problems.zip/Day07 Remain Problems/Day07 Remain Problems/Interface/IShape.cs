﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day07_Remain_Problems.Interface
{
    public interface IShape
    {
        double Area { get; }   // get-only property
        void Draw();           // method signature

        // Default implementation (C# 8.0+)
        void PrintDetails()
        {
            Console.WriteLine($"Shape details -> Area: {Area}");
        }
    }
}
