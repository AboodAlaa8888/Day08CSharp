﻿using Day07_Remain_Problems;
using Day07_Remain_Problems.Abstract;
using Day07_Remain_Problems.Interface;
using System;
using System.Drawing;


class Program
{
    static void Main()
    {

        #region Day07 Part01 Problem7
        //IShape circle = new Circle(7); 
        //circle.Draw();
        //circle.PrintDetails(); 
        #endregion

        #region Day07 Part01 Problem8
        //IMovable myCar = new Car("Toyota"); 
        //myCar.Move();
        #endregion

        #region Day07 Part01 Problem9
        //File1 myFile = new File1("data.txt");

        //IReadable reader = myFile;
        //reader.Read();

        //IWritable writer = myFile;
        //writer.Write();

        //myFile.Read();
        //myFile.Write();
        #endregion

        #region Day07 Part01 Problem10
        //Shape rect = new Rectangle1(10, 5); 
        //rect.Draw();                        
        //Console.WriteLine("Area: " + rect.CalculateArea());
        #endregion


    }
}
