﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using The_Problems.Interface;

namespace The_Problems
{
    internal class CircleI : IShape
    {
        private double radius;

        public CircleI(double r)
        {
            radius = r;
        }

        public double GetArea() => Math.PI * radius * radius;

        public void Display() => Console.WriteLine("This is a circle (interface).");
    }
}
