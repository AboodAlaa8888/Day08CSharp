﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace The_Problems
{
    internal class Product : IComparable
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }

        public int CompareTo(object obj)
        {
            if (!(obj is Product))
                throw new ArgumentException("Object is not an Product");
            Product other = (Product)obj;
            if (this.Price > other.Price)
                return 1;
            else if (this.Price < other.Price)
                return -1;
            else
                return 0;
        }

        public override string ToString()
        {
            return $"Id: {Id}, Name: {Name}, Price: {Price}";
        }
    }
}
