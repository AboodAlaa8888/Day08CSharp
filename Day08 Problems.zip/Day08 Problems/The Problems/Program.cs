﻿using System;
using The_Problems;
using The_Problems.Abstract;
using The_Problems.Interface;


class Program
{
    static void Main()
    {
        #region Day08 Part01 Problem1
        //IVehicle myCar = new Car();
        //IVehicle myBike = new Bike();

        //myCar.StartEngine();
        //myCar.StopEngine();

        //myBike.StartEngine();
        //myBike.StopEngine();
        #endregion

        #region Day08 Part01 Problem2
        //// Abstract class usage
        //Shape rect = new Rectangle(5, 4);
        //Shape circ = new Circle(3);

        //rect.Display();
        //Console.WriteLine("Area: " + rect.GetArea());

        //circ.Display();
        //Console.WriteLine("Area: " + circ.GetArea());

        //// Interface usage
        //IShape rectI = new RectangleI(5, 4);
        //IShape circI = new CircleI(3);

        //rectI.Display();
        //Console.WriteLine("Area: " + rectI.GetArea());

        //circI.Display();
        //Console.WriteLine("Area: " + circI.GetArea());
        #endregion

        #region Day08 Part01 Problem3
        //Product[] products =
        //{
        //    new Product { Id = 1, Name = "Laptop", Price = 800 },
        //    new Product { Id = 2, Name = "Phone",  Price = 500 },
        //    new Product { Id = 3, Name = "Tablet", Price = 300 },
        //    new Product { Id = 4, Name = "Monitor", Price = 200 }
        //};

        //Array.Sort(products);

        //Console.WriteLine("Products sorted by Price:");
        //foreach (var p in products)
        //{
        //    Console.WriteLine(p); // calls ToString()
        //}
        #endregion

        #region Day08 Part01 Problem4
        //Student s1 = new Student(1, "Ali", 90);
        //Student shallowCopy = s1;
        //Student deepCopy = new Student(s1);

        //s1.Grade.Value = 50;

        //Console.WriteLine("After modifying original student grade:");
        //Console.WriteLine("Original: " + s1);
        //Console.WriteLine("Shallow:  " + shallowCopy);
        //Console.WriteLine("Deep:     " + deepCopy);
        #endregion

        #region Day08 Part01 Problem5
        //Robot r = new Robot();
        //r.Walk();

        //IWalkable walkableRobot = r;
        //walkableRobot.Walk();
        #endregion

        #region Day08 Part01 Problem6
        //Account acc = new Account();

        //acc.AccountId = 101;
        //acc.AccountHolder = "Ahmed";
        //acc.Balance = 5000;

        //Console.WriteLine(acc); 

        //acc.Balance = -100;
        //Console.WriteLine(acc); 
        #endregion

        #region Day08 Part01 Problem7
        //ILogger logger = new ConsoleLogger();
        //logger.Log("Hello World!");
        #endregion

        #region Day08 Part01 Problem8
        //Book b1 = new Book();
        //Book b2 = new Book("The Alchemist");
        //Book b3 = new Book("1984", "George Orwell");

        //Console.WriteLine(b1);
        //Console.WriteLine(b2);
        //Console.WriteLine(b3);
        #endregion


        #region Day08 Part02 Task1
        //static void PrintTenShapes(IShapeSeries series)
        //{
        //    series.ResetSeries();
        //    for (int i = 0; i < 10; i++)
        //    {
        //        series.GetNextArea();
        //        Console.WriteLine($"Shape {i + 1}: Area = {series.CurrentShapeArea}");
        //    }
        //}

        //Console.WriteLine("=== Shape Series: Squares ===");
        //PrintTenShapes(new SquareSeries());

        //Console.WriteLine("\n=== Shape Series: Circles ===");
        //PrintTenShapes(new CircleSeries());
        #endregion

        #region Day08 Part02 Task2
        //Console.WriteLine("\n=== Sorting Shapes by Area ===");
        //Shape2[] shapes =
        //{
        //    new Shape2 { Name="Square", Area=25 },
        //    new Shape2 { Name="Circle", Area=78.5 },
        //    new Shape2 { Name="Rectangle", Area=40 }
        //};
        //Array.Sort(shapes);
        //foreach (var s in shapes)
        //    Console.WriteLine(s);
        #endregion

        #region Day08 Part02 Task3
        //Console.WriteLine("\n=== Geometric Shapes (Abstract Class) ===");
        //GeometricShape tri = new Triangle2 { Dimension1 = 3, Dimension2 = 4 };
        //GeometricShape rect = new Rectangle2 { Dimension1 = 5, Dimension2 = 6 };
        //Console.WriteLine($"Triangle: Area={tri.CalculateArea()}, Perimeter={tri.Perimeter}");
        //Console.WriteLine($"Rectangle: Area={rect.CalculateArea()}, Perimeter={rect.Perimeter}");
        #endregion

        #region Day08 Part02 Task4
        //Console.WriteLine("\n=== Selection Sort on Shape Areas ===");
        //int[] areas = { 25, 78, 40, 12, 5 };
        //SortingUtils.SelectionSort(areas);
        //Console.WriteLine("Sorted Areas: " + string.Join(", ", areas));
        #endregion

        #region Day08 Part02 Task5
        //Console.WriteLine("\n=== Shape Factory ===");
        //GeometricShape f1 = ShapeFactory.CreateShape("rectangle", 10, 20);
        //GeometricShape f2 = ShapeFactory.CreateShape("triangle", 6, 8);
        //Console.WriteLine($"Factory Rectangle: Area={f1.CalculateArea()}, Perimeter={f1.Perimeter}");
        //Console.WriteLine($"Factory Triangle: Area={f2.CalculateArea()}, Perimeter={f2.Perimeter}");
        #endregion
    }
}
