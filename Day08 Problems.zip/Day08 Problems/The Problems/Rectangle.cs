﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using The_Problems.Abstract;

namespace The_Problems
{
    internal class Rectangle : Shape
    {
        private double width, height;

        public Rectangle(double w, double h)
        {
            width = w;
            height = h;
        }

        public override double GetArea()
        {
            return width * height;
        }
    }
}
