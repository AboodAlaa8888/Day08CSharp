﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using The_Problems.Abstract;

namespace The_Problems
{
    internal class Rectangle2 : GeometricShape
    {
        public override double CalculateArea()
        { 
            return Dimension1 * Dimension2; 
        }
        public override double Perimeter => 2 * (Dimension1 + Dimension2);
    }
}
