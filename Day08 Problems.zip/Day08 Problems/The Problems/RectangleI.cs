﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using The_Problems.Interface;

namespace The_Problems
{
    internal class RectangleI : IShape
    {
        private double width, height;

        public RectangleI(double w, double h)
        {
            width = w;
            height = h;
        }

        public double GetArea() => width * height;

        public void Display() => Console.WriteLine("This is a rectangle (interface).");
    }
}
