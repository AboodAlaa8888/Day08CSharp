﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using The_Problems.Interface;

namespace The_Problems
{
    internal class Robot : IWalkable
    {
        public void Walk()
        {
            Console.WriteLine("Robot is walking in normal mode.");
        }

        void IWalkable.Walk()
        {
            Console.WriteLine("Robot is walking as defined by IWalkable interface.");
        }
    }

}
