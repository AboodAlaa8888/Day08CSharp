﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace The_Problems
{
    internal class Shape2 : IComparable
    {
        public string Name { get; set; }
        public double Area { get; set; }

        public int CompareTo(object obj)
        {
            if (!(obj is Shape2))
                throw new ArgumentException("Object is not an Employee");
            Shape2 other = (Shape2)obj;
            if (this.Area > other.Area)
                return 1;
            else if (this.Area < other.Area)
                return -1;
            else
                return 0;
        }

        public override string ToString()
        {
            return $"{Name} with Area = {Area}";
        }
    }
}
