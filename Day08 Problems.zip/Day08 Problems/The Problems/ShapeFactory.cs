﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using The_Problems.Abstract;

namespace The_Problems
{
    internal class ShapeFactory
    {
        public static GeometricShape CreateShape(string shapeType, double dim1, double dim2)
        {
            switch (shapeType.ToLower())
            {
                case "rectangle": 
                    return new Rectangle2 { Dimension1 = dim1, Dimension2 = dim2 };
                    break;
                case "triangle": 
                    return new Triangle2 { Dimension1 = dim1, Dimension2 = dim2 };
                    break;
                default: 
                    throw new ArgumentException("Unknown shape type");
                    break;
            }
        }
    }
}
