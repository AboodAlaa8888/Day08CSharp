﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace The_Problems
{
    internal class GradeInfo
    {
        public int Value { get; set; }
    }

    internal class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public GradeInfo Grade { get; set; } // reference type to demonstrate deep copy

        // default constructor 
        public Student(int id, string name, int gradeValue)
        {
            Id = id;
            Name = name;
            Grade = new GradeInfo { Value = gradeValue };
        }

        // copy constructor 
        public Student(Student other)
        {
            Id = other.Id;
            Name = other.Name;
            Grade = new GradeInfo { Value = other.Grade.Value }; // deep copy
        }

        public override string ToString()
        {
            return $"Id: {Id}, Name: {Name}, Grade: {Grade.Value}";
        }
    }
}
